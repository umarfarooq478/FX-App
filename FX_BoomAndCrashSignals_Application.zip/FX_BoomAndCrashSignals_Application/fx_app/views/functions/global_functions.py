import random

from flask_mail import Message
from passlib.apps import custom_app_context as pwd_context

from fx_app.extensions.extensions import mail
from fx_app import config


def encrypt_password(password):
    return pwd_context.encrypt(password)


def check_encrypted_password(password, hashed):
    return pwd_context.verify(password, hashed)


def send_email(to, otp):
    msg = Message(
        subject="Password Recovery Email",
        body="Your OTP for Reset Password is " + str(otp),
        recipients=[to],
        sender=config.MAIL_USERNAME
    )
    mail.send(msg)


def random_pin():
    number = random.randint(1000, 999999)
    return number
