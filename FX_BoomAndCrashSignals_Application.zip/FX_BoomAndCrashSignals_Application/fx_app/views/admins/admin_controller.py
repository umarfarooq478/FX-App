import datetime
import json
import time
import requests
from email_validator import validate_email, EmailNotValidError
from flask import Blueprint, request, jsonify
from flask_jwt_extended import create_access_token, current_user, jwt_required, get_jwt
from fx_app.extensions.extensions import db, jwt as app_jwt
from fx_app.models.curency_category import Currency, category_to_json
from fx_app.models.jwt import TokenBlocklist
from fx_app.models.referral import Referral
from fx_app.models.signal import Signal, signal_to_json
from fx_app.models.users import Users
from fx_app.views.functions.global_functions import encrypt_password, check_encrypted_password

admin_auth_blueprint = Blueprint('admins_auth', __name__)
global response


@admin_auth_blueprint.route('/admin_add_currency_owq56fag', methods=['POST'])
@jwt_required()
def add_currency():
    if request.method == "POST":
        current_id = current_user.id
        admin = Users.query.filter_by(id=current_id, user_role="admin").first()

        if not admin:
            return jsonify(message="user not found", category="error", status=400)

        currency = request.form.get('currency')

        if not currency:
            return jsonify(message="currency required", category="error", status=400)

        old_currency = Currency.query.filter_by(currency=currency).first()
        if old_currency:
            return jsonify(message="currency already exist", category="error", status=400)

        try:
            currency_data = Currency(currency=currency)
            db.session.add(currency_data)
            db.session.commit()
            return jsonify(message="currency added successfully", category="success", status=200)
        except Exception as err:
            return jsonify(message="error, try again", error=str(err), category="error", status=400)
    else:
        return jsonify(message="method not allowed", category="error", status=400)


@admin_auth_blueprint.route('/getAllCurrency', methods=['GET'])
@jwt_required()
def get_currency():
    if request.method == "GET":
        current_id = current_user.id
        admin = Users.query.filter_by(id=current_id, user_role="admin").first()

        if not admin:
            return jsonify(message="user not found", category="error", status=400)

        currencies = Currency.query.all()
        if not currencies:
            return jsonify(message="no currencies found", category="error", status=400, count=0)
        else:
            try:
                m_currencies = [category_to_json(self=currency) for currency in currencies]
                return jsonify(message="currencies found", data=m_currencies, category="success", status=200,
                               count=len(m_currencies))
            except Exception as err:
                return jsonify(message="error, try again", error=str(err), category="error", status=400)
    else:
        return jsonify(message="method not allowed", category="error", status=400)


@admin_auth_blueprint.route('/admin_getAllSignals_hdr39ur', methods=['GET'])
@jwt_required()
def get_all_signals():
    if request.method == "GET":
        current_id = current_user.id
        admin = Users.query.filter_by(id=current_id, user_role="admin").first()

        if not admin:
            return jsonify(message="user not found", category="error", status=400)

        signals = Signal.query.all()

        if not signals:
            return jsonify(message="no signal found", category="error", status=400, count=0)
        else:
            try:
                m_signals = [signal_to_json(self=signal) for signal in signals]
                return jsonify(message="signals found", data=m_signals, category="success", status=200,
                               count=len(signals))
            except Exception as err:
                return jsonify(message="error, try again", error=str(err), category="error", status=400)
    else:
        return jsonify(message="method not allowed", category="error", status=400)


@admin_auth_blueprint.route('/admin_get_one_signal_hi7wa5iu', methods=['POST'])
@jwt_required()
def get_one_signal():
    if request.method == "POST":
        current_id = current_user.id
        admin = Users.query.filter_by(id=current_id, user_role="admin").first()

        if not admin:
            return jsonify(message="user not found", category="error", status=400)

        signal_id = request.form.get('signal_id')

        signal = Signal.query.get(signal_id)
        if not signal:
            return jsonify(message="no signal found", category="error", status=400, count=0)
        else:
            try:
                m_signal = signal_to_json(signal)
                return jsonify(message="signal found", data=m_signal, category="success", status=200,
                               count=len("1"))
            except Exception as err:
                return jsonify(message="error, try again", error=str(err), category="error", status=400)
    else:
        return jsonify(message="method not allowed", category="error", status=400)


@admin_auth_blueprint.route('/admin_get_profile_7y63t7', methods=['GET'])
@jwt_required()
def get_admin_user_info():
    try:
        current_id = current_user.id
        admin = Users.query.filter_by(id=current_id, user_role="admin").first()

        if not admin:
            return jsonify(message="user not found", category="error", status=400)

        if admin:
            data = {
                "full_name": admin.full_name,
                "email": admin.email,
                "image": admin.image
            }
            return jsonify(data=data, category="success", status=200, message="data found")
        else:
            return jsonify(message="user not found", category="error", status=400)
    except Exception as err:
        return jsonify(message="" + str(err), category="error", status=400)


@admin_auth_blueprint.route('/admin_delete-signal_k7dfr7f', methods=['POST'])
@jwt_required()
def delete_signal():
    if request.method == "POST":
        current_id = current_user.id
        admin = Users.query.filter_by(id=current_id, user_role="admin").first()

        if not admin:
            return jsonify(message="user not found", category="error", status=400)

        try:
            signal_id = request.form.get('signal_id')

            error_messages = []

            if not signal_id:
                error_messages.append("Signal ID required")

            if len(error_messages):
                return jsonify(error=error_messages, category="error", status=400)

            my_signal = Signal.query.filter_by(id=signal_id).first()

            if my_signal:
                my_signal.deleted = "1"

                db.session.add(my_signal)
                db.session.commit()
                return jsonify(message="signal deleted successfully", category="success", status=200)

            else:
                return jsonify(message="error, try again", error="Signal Not Found", category="error", status=400)

        except Exception as err:
            return jsonify(message="error, try again", error=str(err), category="error", status=400)
    else:
        return jsonify(message="method not allowed", category="error", status=400)


@admin_auth_blueprint.route('/admin_updateSignal_dja4jw', methods=['POST'])
@jwt_required()
def update_my_signal():
    if request.method == "POST":
        current_id = current_user.id
        admin = Users.query.filter_by(id=current_id, user_role="admin").first()

        if not admin:
            return jsonify(message="user not found", category="error", status=400)

        try:
            signal_id = request.form.get('signal_id')
            action = request.form.get('action')
            open_price = request.form.get('open_price')
            status = request.form.get('status')
            stop_loss = request.form.get('stop_loss')
            take_profit = request.form.get('take_profit')
            take_profit_2 = request.form.get('take_profit_2')
            take_profit_3 = request.form.get('take_profit_3')
            trade_close = request.form.get('trade_close')
            trade_result = request.form.get('trade_result')
            currency = request.form.get('currency')
            last_update = request.form.get('last_update')
            old_new = request.form.get('old_new')
            probability = request.form.get('probability')
            time_frame = request.form.get('time_frame')
            comment = request.form.get('comment')

            error_messages = ''

            if not signal_id:
                error_messages = error_messages + "Signal ID required ,"
            if not action:
                error_messages = error_messages + "Action required ,"
            if not open_price:
                error_messages = error_messages + "Open Price required ,"
            if not status:
                error_messages = error_messages + "Status required ,"
            if not stop_loss:
                error_messages = error_messages + "Stop loss required ,"
            if not take_profit:
                error_messages = error_messages + "Take profit required ,"
            if not take_profit_2:
                error_messages = error_messages + "Take profit 2 required ,"
            if not take_profit_3:
                error_messages = error_messages + "Take profit 3 required ,"
            if not trade_close:
                error_messages = error_messages + "Trade close required ,"
            if not trade_result:
                error_messages = error_messages + "Trade result required ,"
            if not currency:
                error_messages = error_messages + "Currency required ,"
            if not last_update:
                error_messages = error_messages + "Last update required ,"
            if not old_new:
                error_messages = error_messages + "Old new required ,"
            if not probability:
                error_messages = error_messages + "Probability required ,"
            if not time_frame:
                error_messages = error_messages + "Time frame required ,"

            if error_messages:
                return jsonify(error=error_messages, category="error", status=400)

            my_signal = Signal.query.filter_by(id=signal_id).first()

            if my_signal:
                my_signal.action = str(action)
                my_signal.open_price = str(open_price)
                my_signal.status = str(status)
                my_signal.stop_loss = str(stop_loss)
                my_signal.take_profit = str(take_profit)
                my_signal.take_profit_2 = str(take_profit_2)
                my_signal.take_profit_3 = str(take_profit_3)
                my_signal.trade_close = str(trade_close)
                my_signal.trade_result = str(trade_result)
                my_signal.currency = str(currency)
                my_signal.probability = str(probability)
                my_signal.last_update = str(last_update)
                my_signal.old_new = str(old_new)
                my_signal.time_frame = str(time_frame)
                my_signal.comment = str(comment)

                db.session.add(my_signal)
                db.session.commit()
                return jsonify(message="signal updated successfully", category="success", status=200)

            else:
                return jsonify(message="error, try again", error="Signal Not Found", category="error", status=400)

        except Exception as err:
            return jsonify(message="error, try again", error=str(err), category="error", status=400)
    else:
        return jsonify(message="method not allowed", category="error", status=400)


@admin_auth_blueprint.route('/admin_addSignal_8732154afd', methods=['POST'])
@jwt_required()
def add_signal():
    if request.method == "POST":
        current_id = current_user.id
        admin = Users.query.filter_by(id=current_id, user_role="admin").first()

        if not admin:
            return jsonify(message="user not found", category="error", status=400)

        action = request.form.get('action')
        open_price = request.form.get('open_price')
        status = request.form.get('status')
        stop_loss = request.form.get('stop_loss')
        take_profit = request.form.get('take_profit')
        take_profit_2 = request.form.get('take_profit_2')
        take_profit_3 = request.form.get('take_profit_3')
        trade_close = request.form.get('trade_close')
        trade_opening_time = request.form.get('trade_opening_time')
        trade_result = request.form.get('trade_result')
        currency = request.form.get('currency')
        last_update = request.form.get('last_update')
        old_new = request.form.get('old_new')
        probability = request.form.get('probability')
        time_frame = request.form.get('time_frame')
        comment = request.form.get('comment')
        deleted = request.form.get('deleted')
        error_messages = []

        if not action:
            error_messages.append("action required")
        if not open_price:
            error_messages.append("open_price required")
        if not status:
            error_messages.append("status required")
        if not stop_loss:
            error_messages.append("stop loss required")
        if not take_profit:
            error_messages.append("take profit required")
        if not take_profit_2:
            error_messages.append("take profit 2 required")
        if not take_profit_3:
            error_messages.append("take profit 3 required")
        if not trade_close:
            error_messages.append("trade close required")
        if not trade_opening_time:
            error_messages.append("trade opening time required")
        if not trade_result:
            error_messages.append("trade result required")
        if not currency:
            error_messages.append("currency required")
        if not last_update:
            error_messages.append("last update required")
        if not old_new:
            error_messages.append("old new required")
        if not probability:
            error_messages.append("probability required")
        if not time_frame:
            error_messages.append("time frame required")
        if not deleted:
            error_messages.append("deleted required")
        if len(error_messages):
            return jsonify(error_messages=error_messages, category="error", status=400)

        try:
            signal_data = Signal(action=action, open_price=open_price, status=status, stop_loss=stop_loss,
                                 take_profit=take_profit, take_profit_2=take_profit_2, take_profit_3=take_profit_3,
                                 trade_close=trade_close, trade_opening_time=trade_opening_time,
                                 trade_result=trade_result,
                                 currency=currency, last_update=last_update, old_new=old_new, probability=probability,
                                 time_frame=time_frame, comment=comment, deleted=deleted)
            db.session.add(signal_data)
            db.session.commit()
            return jsonify(message="signal added successfully", category="success", status=200)
        except Exception as err:
            return jsonify(message="error, try again", error=str(err), category="error", status=400)

    else:
        return jsonify(message="method not allowed", category="error", status=400)


@app_jwt.user_lookup_loader
def user_lookup_callback(_jwt_header, jwt_data):
    identity = jwt_data["sub"]
    return Users.query.filter_by(id=identity).one_or_none()


@app_jwt.token_in_blocklist_loader
def check_if_token_revoked(jwt_header, jwt_payload):
    jti = jwt_payload["jti"]
    token = db.session.query(TokenBlocklist.id).filter_by(jti=jti).scalar()
    return token is not None


@admin_auth_blueprint.route('/admin_register_ajh5468fa', methods=['POST'])
def user_registration():
    if request.method == "POST":
        full_name = request.form.get('full_name')
        email = request.form.get('email')
        password = request.form.get('password')
        error_messages = []

        if not full_name:
            error_messages.append("full name required")
        if not email:
            error_messages.append("email required")
        if not password:
            error_messages.append("password required")

        if len(error_messages):
            return jsonify(error_messages=error_messages, category="error", status=400)

        try:
            valid = validate_email(email)
            email = valid.email
        except EmailNotValidError:
            error_messages.append("invalid email")
        user_email = Users.query.filter_by(email=email).first()
        if user_email:
            return jsonify(message="email already exist, please login to continue", category="error", status=400)
        user_data = Users(full_name=full_name, email=email,
                          password=encrypt_password(password), user_role="admin")

        db.session.add(user_data)
        db.session.commit()
        return jsonify(message="user registered successfully", category="success", status=200)
    else:
        return jsonify(message="method not allowed", category="error", status=400)


@admin_auth_blueprint.route('/admin_login_frds34daf', methods=['POST'])
def user_login():
    if request.method == "POST":
        email = request.form.get('email')
        password = request.form.get('password')

        if not email:
            return jsonify(message="email required", category="error", status=400)
        if not password:
            return jsonify(message="password required", category="error", status=400)
        user = Users.query.filter_by(email=email, user_role="admin").first()
        if not user:
            return jsonify(message="email doesn't exist", category="error", status=400)
        elif not check_encrypted_password(password, user.password):
            return jsonify(message="invalid password", category="error", status=400)
        expires = datetime.timedelta(days=30)
        access_token = create_access_token(identity=user.id, expires_delta=expires)

        return jsonify(message="login successful", access_token=str(access_token), category="success", status=200)
    else:
        return jsonify(message="method not allowed", category="error", status=400)


@admin_auth_blueprint.route('/admin_send-notification_d3w2aqr25', methods=['POST'])
@jwt_required()
def send_notification():
    if request.method == "POST":
        current_id = current_user.id
        admin = Users.query.filter_by(id=current_id, user_role="admin").first()

        if not admin:
            return jsonify(message="user not found", category="error", status=400)

        title = request.form.get('title')
        message = request.form.get('message')
        server_token = 'AAAAgu6t2lo' \
                       ':APA91bG8NsRyle7VPGs_8hwThrPgRnCOy01uVOq3OufntoMe5oTC54F6OPtiCZtm' \
                       '_33s1nKwoaMb4FirKLIxSy4vVnA7m8d6cPb1COaPl78Rw7v7mqYO94BYN0wuloyTbVUXD4-pBEvq '

        registration_tokens = []

        users = Users.query.filter_by(user_role="user")
        for user in users:
            if not user.is_deleted:
                if not user.is_blocked:
                    if user.is_approved:
                        if user.device_token:
                            registration_tokens.append(user.device_token)

        error_messages = []

        if not title:
            error_messages.append("notification title required")
        if not message:
            error_messages.append("notification message body required")
        if not registration_tokens:
            error_messages.append("no user found to send notification")

        if len(error_messages):
            return jsonify(message=error_messages, category="error", status=400)

        headers = {
            'Content-Type': 'application/json',
            'Authorization': 'key=' + server_token,
        }

        send_count = 0
        for device_token in registration_tokens:
            body = {
                'notification': {'title': title,
                                 'body': message
                                 },
                'to':
                    device_token,
                'priority': 'high',
                #   'data': dataPayLoad,
            }
            my_response = requests.post("https://fcm.googleapis.com/fcm/send", headers=headers, data=json.dumps(body))

            if my_response.status_code == 200:
                send_count = send_count + 1

        registration_tokens = []

        admins = Users.query.filter_by(user_role="admin")
        for admin in admins:
            if admin.device_token:
                registration_tokens.append(admin.device_token)
        if not registration_tokens:
            error_messages.append("no admins token found to send notification")
            return jsonify(message=error_messages, category="error", status=400)

        for device_token in registration_tokens:
            body = {
                'notification': {'title': "Notification sent to " + str(send_count) + " Users",
                                 'body': "Message : " + title + " " + message
                                 },
                'to':
                    device_token,
                'priority': 'high',
                #   'data': dataPayLoad,
            }
            my_response = requests.post("https://fcm.googleapis.com/fcm/send", headers=headers, data=json.dumps(body))

        return jsonify(message="signal sent to all users and admins", category="success", status=200)
    else:
        return jsonify(message="method not allowed", category="error", status=400)


@admin_auth_blueprint.route('/admin_get-all-users_y4rein743', methods=['POST'])
@jwt_required()
def get_users():
    if request.method == "POST":
        current_id = current_user.id
        admin = Users.query.filter_by(id=current_id, user_role="admin").first()

        if not admin:
            return jsonify(message="user not found", category="error", status=400)

        try:
            filter_by = request.form.get('filter')
            query = request.form.get('query')

            error_messages = []

            if not filter_by:
                error_messages.append("Filter required")

            if len(error_messages):
                return jsonify(error=error_messages, category="error", status=400)

            m_users = []
            m_count = []
            users_referred_by = []

            users = Users.query.filter_by(user_role="user")
        except Exception as err:
            return jsonify(message="error, try again", error=str(err), category="error", status=400)

        try:
            if filter_by == "All":
                for user in users:
                    if not user.is_deleted:
                        m_users.append(user)

                        coupon_referred_count = Referral.query.filter_by(signed_up_by_id=user.id).count()

                        user_referred_by = Referral.query.filter_by(user_id=user.id).first()
                        if user_referred_by:
                            m_referred_by = Users.query.filter_by(id=user_referred_by.signed_up_by_id).first()

                            if m_referred_by:
                                users_referred_by.append(m_referred_by.email)
                            else:
                                users_referred_by.append('')
                        else:
                            users_referred_by.append('')

                        if coupon_referred_count:
                            m_count.append(coupon_referred_count)
                        else:
                            m_count.append(0)

            elif filter_by == "Not Approved":
                for user in users:
                    if not user.is_deleted:
                        if not user.is_blocked:
                            if not user.is_approved:
                                m_users.append(user)

                                coupon_referred_count = Referral.query.filter_by(signed_up_by_id=user.id).count()

                                user_referred_by = Referral.query.filter_by(user_id=user.id).first()
                                if user_referred_by:
                                    m_referred_by = Users.query.filter_by(id=user_referred_by.signed_up_by_id).first()

                                    if m_referred_by:
                                        users_referred_by.append(m_referred_by.email)
                                    else:
                                        users_referred_by.append('')
                                else:
                                    users_referred_by.append('')

                                if coupon_referred_count:
                                    m_count.append(coupon_referred_count)
                                else:
                                    m_count.append(0)

            elif filter_by == "Un Complete":
                for user in users:
                    if not user.is_deleted:
                        if not user.is_completed:
                            if not user.is_blocked:
                                m_users.append(user)

                                coupon_referred_count = Referral.query.filter_by(signed_up_by_id=user.id).count()

                                user_referred_by = Referral.query.filter_by(user_id=user.id).first()
                                if user_referred_by:
                                    m_referred_by = Users.query.filter_by(id=user_referred_by.signed_up_by_id).first()

                                    if m_referred_by:
                                        users_referred_by.append(m_referred_by.email)
                                    else:
                                        users_referred_by.append('')
                                else:
                                    users_referred_by.append('')

                                if coupon_referred_count:
                                    m_count.append(coupon_referred_count)
                                else:
                                    m_count.append(0)

            elif filter_by == "Blocked":
                for user in users:
                    if not user.is_deleted:
                        if user.is_blocked:
                            m_users.append(user)

                            coupon_referred_count = Referral.query.filter_by(signed_up_by_id=user.id).count()

                            user_referred_by = Referral.query.filter_by(user_id=user.id).first()
                            if user_referred_by:
                                m_referred_by = Users.query.filter_by(id=user_referred_by.signed_up_by_id).first()

                                if m_referred_by:
                                    users_referred_by.append(m_referred_by.email)
                                else:
                                    users_referred_by.append('')
                            else:
                                users_referred_by.append('')

                            if coupon_referred_count:
                                m_count.append(coupon_referred_count)
                            else:
                                m_count.append(0)

            elif filter_by == "Search":
                if query:
                    for user in users:
                        if not user.is_deleted:
                            if not user.is_blocked:
                                if query in user.email or query in user.phone:
                                    m_users.append(user)

                                    coupon_referred_count = Referral.query.filter_by(signed_up_by_id=user.id).count()

                                    user_referred_by = Referral.query.filter_by(user_id=user.id).first()
                                    if user_referred_by:
                                        m_referred_by = Users.query.filter_by(id=user_referred_by.signed_up_by_id).first()

                                        if m_referred_by:
                                            users_referred_by.append(m_referred_by.email)
                                        else:
                                            users_referred_by.append('')
                                    else:
                                        users_referred_by.append('')

                                    if coupon_referred_count:
                                        m_count.append(coupon_referred_count)
                                    else:
                                        m_count.append(0)
                else:
                    return jsonify(message="error, try again", error=str("Query Missing"), category="error",
                                   status=400)
            else:
                return jsonify(message="error, try again", error=str("No matching User"), category="error", status=400)

        except Exception as err:
            return jsonify(message="error, try again", error=str(err), category="error", status=400)

        try:
            m_users_list = []

            for m_user in range(len(m_users)):
                m_users_list.append({
                    "id": m_users[m_user].id,
                    "full_name": m_users[m_user].full_name,
                    "email": m_users[m_user].email,
                    "coupon_code": m_users[m_user].coupon_code,
                    "phone": m_users[m_user].phone,
                    "image": m_users[m_user].image,
                    "created_at": m_users[m_user].created_at,
                    "is_deleted": m_users[m_user].is_deleted,
                    "is_blocked": m_users[m_user].is_blocked,
                    "is_approved": m_users[m_user].is_approved,
                    "is_completed": m_users[m_user].is_completed,
                    "device_token": m_users[m_user].device_token,
                    "referred_count": m_count[m_user],
                    "referred_by": users_referred_by[m_user]
                })

            return jsonify(message="users found", count=len(m_users_list), data=m_users_list,
                           category="success", status=200, )
        except Exception as err:
            return jsonify(message="error here, try again", error=str(err), category="error", status=400)
    else:
        return jsonify(message="method not allowed", category="error", status=400)


@admin_auth_blueprint.route('/admin_get-referred-users_73rg386e', methods=['POST'])
@jwt_required()
def get_referred_users_by_id():
    if request.method == "POST":
        current_id = current_user.id
        admin = Users.query.filter_by(id=current_id, user_role="admin").first()

        if not admin:
            return jsonify(message="user not found", category="error", status=400)

        try:
            referred_by = request.form.get('referred_by')

            error_messages = []

            if not referred_by:
                error_messages.append("Referred by is required")

            if len(error_messages):
                return jsonify(message=error_messages, category="error", status=400)

        except Exception as err:
            return jsonify(message="error, try again", error=str(err), category="error", status=400)

        m_referred_users = []
        my_referred_users_query = Referral.query.filter_by(signed_up_by_id=referred_by).all()

        if my_referred_users_query:
            for ref_usr in my_referred_users_query:

                my_referred_user_query = Users.query.filter_by(id=ref_usr.user_id).first()

                if my_referred_user_query:
                    m_referred_users.append(
                        {
                            "id": my_referred_user_query.id,
                            "full_name": my_referred_user_query.full_name,
                            "email": my_referred_user_query.email,
                            "phone": my_referred_user_query.phone,
                            "image": my_referred_user_query.image,
                        })

        try:
            if m_referred_users:
                return jsonify(message="users found", count=len(m_referred_users), data=m_referred_users,
                               category="success", status=200)
            else:
                return jsonify(message="error, try again", error=str("No User referred"), category="error", status=400)

        except Exception as err:
            return jsonify(message="error, try again", error=str(err), category="error", status=400)
    else:
        return jsonify(message="method not allowed", category="error", status=400)


@admin_auth_blueprint.route('/admin_delete-user_27894ds', methods=['POST'])
@jwt_required()
def delete_user():
    if request.method == "POST":
        current_id = current_user.id
        admin = Users.query.filter_by(id=current_id, user_role="admin").first()

        if not admin:
            return jsonify(message="user not found", category="error", status=400)

        try:
            user_id = request.form.get('user_id')

            error_messages = []

            if not user_id:
                error_messages.append("User ID required")

            if len(error_messages):
                return jsonify(error=error_messages, category="error", status=400)

            my_user = Users.query.filter_by(id=user_id).first()

            if my_user:
                my_user.is_blocked = True
                my_user.is_deleted = True

                db.session.add(my_user)
                db.session.commit()
                return jsonify(message="user updated successfully", category="success", status=200)

            else:
                return jsonify(message="error, try again", error="User Not Found", category="error", status=400)

        except Exception as err:
            return jsonify(message="error, try again", error=str(err), category="error", status=400)
    else:
        return jsonify(message="method not allowed", category="error", status=400)


@admin_auth_blueprint.route('/admin_unblock-user_27894ds', methods=['POST'])
@jwt_required()
def unblock_user():
    if request.method == "POST":
        current_id = current_user.id
        admin = Users.query.filter_by(id=current_id, user_role="admin").first()

        if not admin:
            return jsonify(message="user not found", category="error", status=400)

        try:
            user_id = request.form.get('user_id')

            error_messages = []

            if not user_id:
                error_messages.append("User ID required")

            if len(error_messages):
                return jsonify(error=error_messages, category="error", status=400)

            my_user = Users.query.filter_by(id=user_id).first()

            if my_user:
                my_user.is_blocked = False
                db.session.add(my_user)
                db.session.commit()
                return jsonify(message="user updated successfully", category="success", status=200)

            else:
                return jsonify(message="error, try again", error="User Not Found", category="error", status=400)
        except Exception as err:
            return jsonify(message="error, try again", error=str(err), category="error", status=400)
    else:
        return jsonify(message="method not allowed", category="error", status=400)


@admin_auth_blueprint.route('/admin_block-user_27894ds', methods=['POST'])
@jwt_required()
def block_user():
    if request.method == "POST":
        current_id = current_user.id
        admin = Users.query.filter_by(id=current_id, user_role="admin").first()

        if not admin:
            return jsonify(message="user not found", category="error", status=400)

        try:
            user_id = request.form.get('user_id')
            print(user_id)
            error_messages = []

            if not user_id:
                error_messages.append("User ID required")

            if len(error_messages):
                return jsonify(error=error_messages, category="error", status=400)

            my_user = Users.query.filter_by(id=user_id).first()

            if my_user:
                my_user.is_blocked = True
                db.session.add(my_user)
                db.session.commit()
                return jsonify(message="user updated successfully", category="success", status=200)

            else:
                return jsonify(message="error, try again", error="User Not Found", category="error", status=400)

        except Exception as err:
            return jsonify(message="error, try again", error=str(err), category="error", status=400)
    else:
        return jsonify(message="method not allowed", category="error", status=400)


@admin_auth_blueprint.route('/admin_approve-user_y832t7v', methods=['POST'])
@jwt_required()
def approve_user():
    if request.method == "POST":
        current_id = current_user.id
        admin = Users.query.filter_by(id=current_id, user_role="admin").first()

        if not admin:
            return jsonify(message="user not found", category="error", status=400)

        try:
            user_id = request.form.get('user_id')
            trail_time = request.form.get('trail_time')

            error_messages = []

            if not user_id:
                error_messages.append("User ID required")

            if not trail_time:
                error_messages.append("Trail Time required")

            if len(error_messages):
                return jsonify(error=error_messages, category="error", status=400)

            my_user = Users.query.filter_by(id=user_id).first()

            if my_user:
                my_user.is_approved = True

                if trail_time == '7':
                    next_day_date = datetime.datetime.today() + datetime.timedelta(days=7)
                    date = str(next_day_date.day) + "/" + str(next_day_date.month) + "/" + str(next_day_date.year)
                    timestamp = time.mktime(datetime.datetime.strptime(date, "%d/%m/%Y").timetuple())
                    print("Today's date timeStamp:", timestamp)
                    print(next_day_date)

                    my_user.forever = False
                    my_user.time_trail = str(timestamp)
                elif trail_time == '14':
                    next_day_date = datetime.datetime.today() + datetime.timedelta(days=14)
                    date = str(next_day_date.day) + "/" + str(next_day_date.month) + "/" + str(next_day_date.year)
                    timestamp = time.mktime(datetime.datetime.strptime(date, "%d/%m/%Y").timetuple())
                    print("Today's date timeStamp:", timestamp)
                    print(next_day_date)

                    my_user.forever = False
                    my_user.time_trail = str(timestamp)
                elif trail_time == '28':
                    next_day_date = datetime.datetime.today() + datetime.timedelta(days=28)
                    date = str(next_day_date.day) + "/" + str(next_day_date.month) + "/" + str(next_day_date.year)
                    timestamp = time.mktime(datetime.datetime.strptime(date, "%d/%m/%Y").timetuple())
                    print("Today's date timeStamp:", timestamp)
                    print(next_day_date)

                    my_user.forever = False
                    my_user.time_trail = str(timestamp)
                elif trail_time == 'Forever':
                    print("Time Trail", trail_time)

                    my_user.forever = True
                else:
                    return jsonify(error="invalid trail period sent", category="error", status=400)

                db.session.add(my_user)
                db.session.commit()
                send_notification_to_user_profile_approved(my_user.id)
                return jsonify(message="user updated successfully", category="success", status=200)

            else:
                return jsonify(message="error, try again", error="User Not Found", category="error", status=400)

        except Exception as err:
            return jsonify(message="error, try again", error=str(err), category="error", status=400)
    else:
        return jsonify(message="method not allowed", category="error", status=400)


def send_notification_to_user_profile_approved(user_id):
    if request.method == "POST":

        title = 'Approval'
        message = 'Your Profile is Approved by Admin'
        server_token = 'AAAAgu6t2lo' \
                       ':APA91bG8NsRyle7VPGs_8hwThrPgRnCOy01uVOq3OufntoMe5oTC54F6OPtiCZtm' \
                       '_33s1nKwoaMb4FirKLIxSy4vVnA7m8d6cPb1COaPl78Rw7v7mqYO94BYN0wuloyTbVUXD4-pBEvq '

        error_messages = []

        headers = {
            'Content-Type': 'application/json',
            'Authorization': 'key=' + server_token,
        }

        user = Users.query.filter_by(id=user_id).first()

        if not user.device_token:
            error_messages.append("no token found to send notification")
            return jsonify(message=error_messages, category="error", status=400)

        body = {
            'notification': {'title': title,
                             'body': message
                             },
            'to':
                user.device_token,
            'priority': 'high',
            #   'data': dataPayLoad,
        }
        my_response = requests.post("https://fcm.googleapis.com/fcm/send", headers=headers, data=json.dumps(body))

        return jsonify(message="approval request sent to all and admins", category="success", status=200)


@admin_auth_blueprint.route('/admin_get-counter_28y63243', methods=['GET'])
@jwt_required()
def get_counter():
    if request.method == "GET":
        current_id = current_user.id
        admin = Users.query.filter_by(id=current_id, user_role="admin").first()

        if not admin:
            return jsonify(message="user not found", category="error", status=400)

        try:

            approval_requests = 0
            all_users = 0
            all_signals = 0
            active_signals = 0

            users = Users.query.filter_by(user_role="user")
            signals = Signal.query.all()

            if users:
                for user in users:
                    if user.is_deleted == 0:
                        if user.is_blocked == 0:
                            all_users = all_users + 1
                            if user.is_approved == 0:
                                approval_requests = approval_requests + 1

            if signals:
                for signal in signals:
                    if signal.deleted == '0':
                        all_signals = all_signals + 1
                        if signal.status == 'ACTIVE':
                            active_signals = active_signals + 1

            return jsonify(message="success", approval_requests=approval_requests, category="success", status=200,
                           all_users=all_users, all_signals=all_signals, active_signals=active_signals)

        except Exception as err:
            return jsonify(message="error, try again", error=str(err), category="error", status=400)

    else:
        return jsonify(message="method not allowed", category="error", status=400)


@admin_auth_blueprint.route("/admin_logout_fa24rdfs74", methods=["DELETE"])
@jwt_required()
def modify_token():
    if request.method == "DELETE":
        jti = get_jwt()["jti"]
        now = datetime.datetime.now()
        db.session.add(TokenBlocklist(jti=jti, created_at=now))
        db.session.commit()
        return jsonify(message="JWT revoked", category="success", status=200)
    else:
        return jsonify(message="method not allowed", category="error", status=400)


@admin_auth_blueprint.route('/admin_editUser_r23475qw3f', methods=['PATCH'])
@jwt_required()
def edit_user():
    if request.method == "PATCH":
        current_id = current_user.id
        admin = Users.query.filter_by(id=current_id, user_role="admin").first()

        if not admin:
            return jsonify(message="user not found", category="error", status=400)

        full_name = request.form.get('full_name')
        email = request.form.get('email')
        error_messages = []

        if not full_name:
            error_messages.append("full name required")
        if not email:
            error_messages.append("email required")

        if len(error_messages):
            return jsonify(error_messages=error_messages, category="error", status=400)

        try:
            valid = validate_email(email)
            email = valid.email
        except EmailNotValidError:
            error_messages.append("invalid email")

        try:
            if Users.query.filter_by(id=current_user.id).update(dict(full_name=full_name, email=email)):
                db.session.commit()
                return jsonify(message="user updated successfully", category="success", status=200)
        except Exception as err:
            return jsonify(message="error, try again", error=str(err), category="error", status=400)
    else:
        return jsonify(message="method not allowed", category="error", status=400)


@admin_auth_blueprint.route('/admin_change-password-g782tw3h', methods=['POST'])
@jwt_required()
def change_password():
    if request.method == 'POST':
        current_id = current_user.id
        admin = Users.query.filter_by(id=current_id, user_role="admin").first()

        if not admin:
            return jsonify(message="user not found", category="error", status=400)

        current_password = request.form.get('current_password')
        n_password = request.form.get('new_password')
        confirm_password = request.form.get("confirm_password")
        if n_password != confirm_password:
            return jsonify(message="new passwords should be same", category="error", status=400)
        if not current_password:
            return jsonify(message="current password required", category="error", status=400)
        if not n_password:
            return jsonify(message="new password required", category="error", status=400)

        user = Users.query.filter_by(id=current_user.id).first()
        if check_encrypted_password(current_password, user.password):
            if check_encrypted_password(n_password, user.password):
                return jsonify(message="password can't be same as current password", category="error", status=400)
            if Users.query.filter_by(id=current_user.id).update(dict(password=encrypt_password(n_password))):
                db.session.commit()
                return jsonify(message="password updated successfully", category="success", status=200)
            else:
                return jsonify(message="invalid credentials", category="error", status=400)
        else:
            return jsonify(message="invalid current password", category="error", status=400)

    else:
        return jsonify(message="method not allowed", category="error", status=400)


@admin_auth_blueprint.route('/admin_addDeviceToken_213rfd3sa', methods=['PATCH'])
@jwt_required()
def add_device_token():
    try:
        if request.method == "PATCH":
            current_id = current_user.id
            admin = Users.query.filter_by(id=current_id, user_role="admin").first()

            if not admin:
                return jsonify(message="user not found", category="error", status=400)

            device_token = request.form.get('device_token')
            error_messages = []

            if not device_token:
                error_messages.append("device token required")

            if len(error_messages):
                return jsonify(error_messages=error_messages, category="error", status=400)

            try:
                if Users.query.filter_by(id=current_user.id).update(dict(device_token=device_token)):
                    db.session.commit()
                    return jsonify(message="user updated successfully", category="success", status=200)
            except Exception as err:
                return jsonify(message="error, try again", error=str(err), category="error", status=400)

        else:
            return jsonify(message="method not allowed", category="error", status=400)

    except Exception as err:
        return jsonify(message="error, try again", error=str(err), category="error", status=400)
