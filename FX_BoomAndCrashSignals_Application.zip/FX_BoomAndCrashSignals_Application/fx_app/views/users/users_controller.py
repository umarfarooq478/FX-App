import datetime
import json
import time
import requests
import random
import string
from email_validator import validate_email, EmailNotValidError
from flask import Blueprint, request, jsonify
from flask_jwt_extended import create_access_token, current_user, jwt_required, get_jwt
from fx_app.extensions.extensions import db, jwt as app_jwt
from fx_app.models.referral import Referral
from fx_app.models.signal import Signal, signal_to_json
from fx_app.models.users import Users
from fx_app.models.jwt import TokenBlocklist
from fx_app.views.functions.global_functions import encrypt_password, check_encrypted_password, send_email, \
    random_pin

users_auth_blueprint = Blueprint('users_auth', __name__)

global response


@users_auth_blueprint.route('/', methods=['GET'])
@jwt_required()
def home():
    return jsonify(message="running")


@users_auth_blueprint.route('/register', methods=['POST'])
def user_registration():
    if request.method == "POST":
        full_name = request.form.get('full_name')
        email = request.form.get('email')
        phone = request.form.get('phone')
        password = request.form.get('password')
        coupon_code = request.form.get('coupon_code')

        error_messages = []

        if not full_name:
            error_messages.append("full name required")
        if not email:
            error_messages.append("email required")
        if not password:
            error_messages.append("password required")

        if len(error_messages):
            return jsonify(message=error_messages, error_messages=error_messages, category="error", status=400)

        if coupon_code:
            user_data_coupon = Users.query.filter_by(coupon_code=coupon_code).first()
            if not user_data_coupon:
                return jsonify(error_messages="invalid coupon code, use correct one", category="error", status=400)

        try:
            valid = validate_email(email)
            email = valid.email
        except EmailNotValidError:
            error_messages.append("invalid email")

        user_email = Users.query.filter_by(email=email).first()

        if user_email:
            return jsonify(message="email already exist, please login to continue",
                           error_messages="email already exist, please login to continue", category="error", status=400)

        my_coupon_code = ''
        while 1:
            source = string.ascii_letters + string.digits
            result_str = ''.join((random.choice(source) for i in range(8)))

            check_coupon_code = Users.query.filter_by(coupon_code=result_str).first()
            if check_coupon_code:
                continue
            else:
                my_coupon_code = result_str
                break

        user_data = Users(full_name=full_name, email=email,
                          password=encrypt_password(password),
                          phone=phone, coupon_code=my_coupon_code)

        db.session.add(user_data)
        db.session.commit()

        expires = datetime.timedelta(days=30)
        access_token = create_access_token(identity=user_data.id, expires_delta=expires)

        if coupon_code:
            user_referred_by = Users.query.filter_by(coupon_code=coupon_code).first()

            referral_data = Referral(user_id=user_data.id,
                                     signed_up_by_id=user_referred_by.id,
                                     signed_up_email=user_data.email, coupon_code=coupon_code)

            db.session.add(referral_data)
            db.session.commit()

        title = 'Approval Request'
        message = 'New Approval Request arrived'
        server_token = 'AAAAgu6t2lo' \
                       ':APA91bG8NsRyle7VPGs_8hwThrPgRnCOy01uVOq3OufntoMe5oTC54F6OPtiCZtm' \
                       '_33s1nKwoaMb4FirKLIxSy4vVnA7m8d6cPb1COaPl78Rw7v7mqYO94BYN0wuloyTbVUXD4-pBEvq '

        headers = {
            'Content-Type': 'application/json',
            'Authorization': 'key=' + server_token,
        }

        registration_tokens = []

        admins = Users.query.filter_by(user_role="admin")
        for admin in admins:
            if admin.device_token:
                registration_tokens.append(admin.device_token)
        if not registration_tokens:
            return jsonify(message="user registered successfully", error_messages="sign up successful",
                           access_token=access_token, category="success", status=200)

        for device_token in registration_tokens:
            body = {
                'notification': {'title': title,
                                 'body': message
                                 },
                'to':
                    device_token,
                'priority': 'high',
            }
            my_response = requests.post("https://fcm.googleapis.com/fcm/send", headers=headers, data=json.dumps(body))

        return jsonify(message="user registered successfully", error_messages="sign up successful",
                       access_token=access_token, category="success", status=200)
    else:
        return jsonify(message="method not allowed", error_messages="method not allowed", category="error", status=400)


@users_auth_blueprint.route('/generate_and_save_coupon', methods=['GET'])
@jwt_required()
def generate_coupon():
    if request.method == "GET":
        user_id = current_user.id
        user = Users.query.filter_by(id=user_id).first()

        if user.coupon_code:
            return jsonify(coupon_code=user.coupon_code, message="coupon found", category="success", status=200)
        else:
            coupon_code = ''
            while 1:
                source = string.ascii_letters + string.digits
                result_str = ''.join((random.choice(source) for i in range(8)))

                check_coupon_code = Users.query.filter_by(coupon_code=result_str).first()
                if check_coupon_code:
                    continue
                else:
                    coupon_code = result_str
                    break

            user.coupon_code = coupon_code
            db.session.add(user)
            db.session.commit()
            return jsonify(coupon_code=user.coupon_code, message="coupon found", category="success", status=200)
    else:
        return jsonify(message="method not allowed", category="error", status=400)


@users_auth_blueprint.route('/get_coupon_count', methods=['GET'])
@jwt_required()
def get_coupon_count():
    if request.method == "GET":
        user_id = current_user.id

        coupon_referred_count = Referral.query.filter_by(signed_up_by_id=user_id).count()

        if coupon_referred_count:
            return jsonify(count=coupon_referred_count, message="found", category="success", status=200)
        else:
            return jsonify(count=0, message="not found", category="success", status=200)
    else:
        return jsonify(message="method not allowed", category="error", status=400)


@users_auth_blueprint.route('/login', methods=['POST'])
def user_login():
    if request.method == "POST":
        email = request.form.get('email')
        password = request.form.get('password')

        if not email:
            return jsonify(message="email required", category="error", status=400)
        if not password:
            return jsonify(message="password required", category="error", status=400)
        user = Users.query.filter_by(email=email, user_role="user").first()
        if not user:
            return jsonify(message="email doesn't exist", category="error", status=400)
        elif not check_encrypted_password(password, user.password):
            return jsonify(message="invalid password", category="error", status=400)
        expires = datetime.timedelta(days=30)
        access_token = create_access_token(identity=user.id, expires_delta=expires)

        return jsonify(message="login successful", access_token=str(access_token), category="success", status=200)
    else:
        return jsonify(message="method not allowed", category="error", status=400)


@users_auth_blueprint.route('/send-notification', methods=['POST'])
def send_notification():
    if request.method == "POST":
        title = request.form.get('title')
        message = request.form.get('message')
        device_token = request.form.get('device-token')
        server_token = 'AAAAgu6t2lo:APA91bG8NsRyle7VPGs_8hwThrPgRnCOy01uVOq3OufntoMe5oTC54F6OPtiCZtm' \
                       '_33s1nKwoaMb4FirKLIxSy4vVnA7m8d6cPb1COaPl78Rw7v7mqYO94BYN0wuloyTbVUXD4-pBEvq'

        error_messages = []

        if not title:
            error_messages.append("notification title required")
        if not message:
            error_messages.append("notification message body required")
        if not device_token:
            error_messages.append("device token required")

        if len(error_messages):
            return jsonify(error_messages=error_messages, category="error", status=400)

        headers = {
            'Content-Type': 'application/json',
            'Authorization': 'key=' + server_token,
        }

        body = {
            'notification': {'title': title,
                             'body': message
                             },
            'to':
                device_token,
            'priority': 'high',
            #   'data': dataPayLoad,
        }
        my_response = requests.post("https://fcm.googleapis.com/fcm/send", headers=headers, data=json.dumps(body))
        print(my_response.status_code)

        print(my_response.json())

        if my_response.status_code == 200:
            return jsonify(message="sent", category="success", status=200)
        else:
            return jsonify(message="failed", category="error", status=400)
    else:
        return jsonify(message="method not allowed", category="error", status=400)


@users_auth_blueprint.route('/forget-password', methods=['POST'])
def forget_password():
    if request.method == "POST":
        email = request.form.get('email')

        if not email:
            return jsonify(message="email required", category="error", status=400)

        if Users.query.filter_by(email=email).first():
            otp = random_pin()

            Users.query.filter_by(email=email).update(dict(recovery=otp, recovery_created_at=datetime.datetime.now()))
            db.session.commit()
            send_email(email, otp)
            return jsonify(message="email sent successfully", category="success", status=200)
        else:
            return jsonify(message="please enter valid email", category="error", status=400)

    else:
        return jsonify(message="method not allowed", category="error", status=400)


@users_auth_blueprint.route('/verify-otp', methods=['POST'])
def verify_otp():
    if request.method == 'POST':
        email = request.form.get('email')
        if not email:
            return jsonify(message="email required", category="error", status=400)
        otp = request.form.get('otp')
        if not otp:
            return jsonify(message="otp required", category="error", status=400)

        users = Users.query.filter_by(email=email).first()
        if users.recovery == int(otp):
            return jsonify(message="otp verified", category="success", status=200)
        else:
            return jsonify(message="invalid otp", category="error", status=400)

    else:
        return jsonify(message="method not allowed", category="error", status=400)


@users_auth_blueprint.route('/new-password', methods=['POST'])
def new_password():
    if request.method == 'POST':
        email = request.form.get('email')
        if not email:
            return jsonify(message="email required", category="error", status=400)
        otp = request.form.get('otp')
        if not otp:
            return jsonify(message="otp required", category="error", status=400)

        new_pass = request.form.get('new_password')
        if not new_pass:
            return jsonify(message="new password required", category="error", status=400)

        user = Users.query.filter_by(email=email, recovery=otp).first()
        if not user:
            return jsonify(message="invalid credentials", category="error", status=400)
        if check_encrypted_password(new_pass, user.password):
            return jsonify(message="password can't be same as current password", category="error", status=400)

        if Users.query.filter_by(email=email, recovery=otp).update(dict(password=encrypt_password(new_pass))):
            db.session.commit()
            return jsonify(message="password changed successfully", category="success", status=200)
        else:
            return jsonify(message="invalid credentials", category="error", status=400)

    else:
        return jsonify(message="method not allowed", category="error", status=400)


@users_auth_blueprint.route("/logout", methods=["DELETE"])
@jwt_required()
def modify_token():
    if request.method == "DELETE":
        jti = get_jwt()["jti"]
        now = datetime.datetime.now()
        db.session.add(TokenBlocklist(jti=jti, created_at=now))

        if Users.query.filter_by(id=current_user.id).update(dict(device_token='')):
            db.session.commit()

        db.session.commit()
        return jsonify(message="JWT revoked", category="success", status=200)
    else:
        return jsonify(message="method not allowed", category="error", status=400)


@app_jwt.user_lookup_loader
def user_lookup_callback(_jwt_header, jwt_data):
    identity = jwt_data["sub"]
    return Users.query.filter_by(id=identity).one_or_none()


@app_jwt.token_in_blocklist_loader
def check_if_token_revoked(jwt_header, jwt_payload):
    jti = jwt_payload["jti"]
    token = db.session.query(TokenBlocklist.id).filter_by(jti=jti).scalar()
    return token is not None


@users_auth_blueprint.route('/getAllSignals', methods=['GET'])
@jwt_required()
def get_signals():
    if request.method == "GET":
        signals = Signal.query.all()
        if not signals:
            return jsonify(message="no signal found", category="error", status=400, count=0)
        else:
            try:
                m_signals = [signal_to_json(self=signal) for signal in signals]
                return jsonify(message="signals found", data=m_signals, category="success", status=200,
                               count=len(signals))
            except Exception as err:
                return jsonify(message="error, try again", error=str(err), category="error", status=400)
    else:
        return jsonify(message="method not allowed", category="error", status=400)


@users_auth_blueprint.route('/get_one_signal', methods=['POST'])
@jwt_required()
def get_one_signal():
    if request.method == "POST":
        signal_id = request.form.get('signal_id')

        signal = Signal.query.get(signal_id)
        if not signal:
            return jsonify(message="no signal found", data='empty', category="error", status=400, count=0)
        else:
            try:
                m_signal = signal_to_json(signal)
                return jsonify(message="signal found", data=m_signal, category="success", status=200,
                               count=len("1"))
            except Exception as err:
                return jsonify(message="error, try again", error=str(err), category="error", status=400)
    else:
        return jsonify(message="method not allowed", category="error", status=400)


@users_auth_blueprint.route('/getUserInfo', methods=['GET'])
@jwt_required()
def get_user_info():
    try:
        user_id = current_user.id
        user = Users.query.filter_by(id=user_id).first()

        if user:
            if user.forever:
                data = {
                    "name": user.full_name,
                    "email": user.email,
                    "phone": user.phone,
                    "is_deleted": user.is_deleted,
                    "is_blocked": user.is_blocked,
                    "is_approved": user.is_approved,
                    "coupon_code": user.coupon_code
                }
                return jsonify(data=data, category="success", status=200)

            if user.time_trail:
                if user.time_trail != "":
                    today = datetime.datetime.today()
                    today_date = str(today.day) + "/" + str(today.month) + "/" + str(today.year)
                    today_timestamp = time.mktime(datetime.datetime.strptime(today_date, "%d/%m/%Y").timetuple())

                    allocated_trial_stamp = user.time_trail

                    if int(float(today_timestamp)) >= int(float(allocated_trial_stamp)):
                        return jsonify(trail=False, message="time trial expired", category="error", status=400)
                    else:
                        data = {
                            "name": user.full_name,
                            "email": user.email,
                            "phone": user.phone,
                            "is_deleted": user.is_deleted,
                            "is_blocked": user.is_blocked,
                            "is_approved": user.is_approved,
                            "coupon_code": user.coupon_code
                        }
                        return jsonify(data=data, category="success", status=200)
                else:
                    return jsonify(message="time trial not found", category="error", status=400, trail=False)
            else:
                return jsonify(message="time trial not found", category="error", status=400, trail=False)
        else:
            return jsonify(message="user not found", category="error", status=400)
    except Exception as err:
        return jsonify(message="" + str(err), category="error", status=400)


@users_auth_blueprint.route('/editUser', methods=['PATCH'])
@jwt_required()
def edit_user():
    if request.method == "PATCH":
        full_name = request.form.get('full_name')
        email = request.form.get('email')
        phone = request.form.get('phone')
        error_messages = []

        if not full_name:
            error_messages.append("full name required")
        if not email:
            error_messages.append("email required")
        if not phone:
            error_messages.append("phone required")

        if len(error_messages):
            return jsonify(error_messages=error_messages, category="error", status=400)

        try:
            valid = validate_email(email)
            email = valid.email
        except EmailNotValidError:
            error_messages.append("invalid email")

        try:
            if Users.query.filter_by(id=current_user.id).update(dict(full_name=full_name, email=email, phone=phone)):
                db.session.commit()
                return jsonify(message="user updated successfully", category="success", status=200)
        except Exception as err:
            return jsonify(message="error, try again", error=str(err), category="error", status=400)
    else:
        return jsonify(message="method not allowed", category="error", status=400)


@users_auth_blueprint.route('/addDeviceToken', methods=['PATCH'])
@jwt_required()
def add_device_token():
    if request.method == "PATCH":
        device_token = request.form.get('device_token')
        error_messages = []

        if not device_token:
            error_messages.append("device token required")

        if len(error_messages):
            return jsonify(error_messages=error_messages, category="error", status=400)

        try:
            if Users.query.filter_by(id=current_user.id).update(dict(device_token=device_token)):
                db.session.commit()
                return jsonify(message="user updated successfully", category="success", status=200)
        except Exception as err:
            return jsonify(message="error, try again", error=str(err), category="error", status=400)
    else:
        return jsonify(message="method not allowed", category="error", status=400)
