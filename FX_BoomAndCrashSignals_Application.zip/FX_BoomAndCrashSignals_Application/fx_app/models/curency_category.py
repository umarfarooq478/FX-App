import datetime

from fx_app.extensions.extensions import db


class Currency(db.Model):
    id = db.Column(db.Integer, primary_key=True, nullable=False)
    currency = db.Column(db.String(400), nullable=False)
    created_at = db.Column(db.DateTime(), default=datetime.datetime.now())


def category_to_json(self):
    return {
        "id": self.id,
        "currency": self.currency,
        "created_at": self.created_at,
    }
