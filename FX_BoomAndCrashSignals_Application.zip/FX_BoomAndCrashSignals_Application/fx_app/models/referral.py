import datetime

from fx_app.extensions.extensions import db


class Referral(db.Model):
    id = db.Column(db.Integer, primary_key=True, nullable=False)
    user_id = db.Column(db.String(40))
    coupon_code = db.Column(db.String(50))
    signed_up_by_id = db.Column(db.String(300))
    signed_up_email = db.Column(db.String(300))
    created_at = db.Column(db.DateTime(), default=datetime.datetime.now())


def referral_to_json(self):
    return {
        "id": self.id,
        "user_id": self.user_id,
        "coupon_code": self.coupon_code,
        "signed_up_by_id": self.signed_up_by_id,
        "signed_up_email": self.signed_up_email,
        "image": self.image,
        "created_at": self.created_at,
    }
