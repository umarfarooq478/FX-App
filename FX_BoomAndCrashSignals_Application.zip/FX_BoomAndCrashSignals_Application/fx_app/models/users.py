import datetime

from fx_app.extensions.extensions import db


class Users(db.Model):
    id = db.Column(db.Integer, primary_key=True, nullable=False)
    full_name = db.Column(db.String(400))
    user_role = db.Column(db.String(400), default="user")
    email = db.Column(db.String(300), default=None)
    phone = db.Column(db.String(400))
    coupon_code = db.Column(db.String(50))
    password = db.Column(db.String(300), default=None)
    image = db.Column(db.String(300), default=None)
    created_at = db.Column(db.DateTime(), default=datetime.datetime.now())
    is_deleted = db.Column(db.Boolean, default=False)
    is_blocked = db.Column(db.Boolean, default=False)
    is_approved = db.Column(db.Boolean, default=False)
    is_completed = db.Column(db.Boolean, default=True)
    device_token = db.Column(db.String(300), default=None)
    forever = db.Column(db.Boolean, default=False)
    time_trail = db.Column(db.String(300), default=None)


def user_to_json(self):
    return {
        "id": self.id,
        "full_name": self.full_name,
        "email": self.email,
        "coupon_code": self.coupon_code,
        "phone": self.phone,
        "image": self.image,
        "created_at": self.created_at,
        "is_deleted": self.is_deleted,
        "is_blocked": self.is_blocked,
        "is_approved": self.is_approved,
        "is_completed": self.is_completed,
        "device_token": self.device_token,
    }
