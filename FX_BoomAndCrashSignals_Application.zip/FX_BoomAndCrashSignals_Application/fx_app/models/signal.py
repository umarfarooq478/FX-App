import datetime

from fx_app.extensions.extensions import db


class Signal(db.Model):
    id = db.Column(db.Integer, primary_key=True, nullable=False)
    action = db.Column(db.String(300), default=None)
    open_price = db.Column(db.String(300), default=None)
    status = db.Column(db.String(300), default=None)
    stop_loss = db.Column(db.String(300), default=None)
    take_profit = db.Column(db.String(300), default=None)
    take_profit_2 = db.Column(db.String(300), default=None)
    take_profit_3 = db.Column(db.String(300), default=None)
    trade_close = db.Column(db.String(300), default=None)
    trade_opening_time = db.Column(db.String(300), default=None)
    trade_result = db.Column(db.String(300), default=None)
    currency = db.Column(db.String(300), default=None)
    last_update = db.Column(db.String(300), default=None)
    old_new = db.Column(db.String(300), default=None)
    probability = db.Column(db.String(300), default=None)
    time_frame = db.Column(db.String(300), default=None)
    comment = db.Column(db.String(300), default=None)
    deleted = db.Column(db.String(300), default=None)
    created_at = db.Column(db.DateTime(), default=datetime.datetime.now())


def signal_to_json(self):
    return {
        "id": self.id,
        "action": self.action,
        "open_price": self.open_price,
        "status": self.status,
        "stop_loss": self.stop_loss,
        "take_profit": self.take_profit,
        "take_profit_2": self.take_profit_2,
        "take_profit_3": self.take_profit_3,
        "trade_close": self.trade_close,
        "trade_opening_time": self.trade_opening_time,
        "trade_result": self.trade_result,
        "currency": self.currency,
        "last_update": self.last_update,
        "old_new": self.old_new,
        "probability": self.probability,
        "time_frame": self.time_frame,
        "comment": self.comment,
        "deleted": self.deleted,
    }