

DEBUG = True
HOST = '127.0.0.1'

SECRET_KEY = "Th1s1sS3CR3T"

MAIL_SERVER = "smtp.gmail.com"
MAIL_PORT = 465
MAIL_USE_TLS = False
MAIL_USE_SSL = True
MAIL_USERNAME = "boomandcrashsignals@gmail.com"
MAIL_PASSWORD = "ItsSecretPasscode4921"

SQLALCHEMY_DATABASE_URI = "mysql://root:MyStrongPassword9.@127.0.0.1/fx_signals_db"
SQLALCHEMY_TRACK_MODIFICATIONS = False

JWT_ACCESS_TOKEN_EXPIRES = "ACCESS_EXPIRES"

API_KEY = "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"

UPLOAD_FOLDER = 'fx_app/media/uploaded_photos/'
ALLOWED_EXTENSIONS = {'png', 'jpg', 'jpeg'}
